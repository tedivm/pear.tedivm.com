typeof a==='string'
b+""!==c+""
d<e===f<g