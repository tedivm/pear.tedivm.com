var a = 1;
var b = 2;